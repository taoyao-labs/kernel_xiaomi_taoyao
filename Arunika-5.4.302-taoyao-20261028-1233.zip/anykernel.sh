#!/sbin/sh
# Kernel-only installation for Xiaomi 12 Lite (taoyao).
properties() { '
kernel.string=Arunika Kernel 5.4.302 | Xiaomi 12 Lite
do.devicecheck=1
do.modules=0
do.systemless=0
do.cleanup=1
do.cleanuponabort=0
device.name1=taoyao
supported.versions=
supported.patchlevels=
supported.vendorpatchlevels=
'; }

BLOCK=boot;
IS_SLOT_DEVICE=1;
SLOT_SELECT=active;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=0;
NO_VBMETA_PARTITION_PATCH=1;
NO_MAGISK_CHECK=1;
NO_BLOCK_DISPLAY=1;

. tools/ak3-core.sh;
split_boot;
flash_boot;
